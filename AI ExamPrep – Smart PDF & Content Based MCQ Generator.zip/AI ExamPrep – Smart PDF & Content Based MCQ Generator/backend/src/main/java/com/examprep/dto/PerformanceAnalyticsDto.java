package com.examprep.dto;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class PerformanceAnalyticsDto {
    private List<WeakAreaDto> weakAreas;
    private List<String> recommendations;
    private Double overallProgress;
    private String geminiSummary;
}
