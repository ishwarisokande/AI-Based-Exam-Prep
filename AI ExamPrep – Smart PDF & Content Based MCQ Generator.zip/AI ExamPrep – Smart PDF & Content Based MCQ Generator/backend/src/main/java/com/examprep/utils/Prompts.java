package com.examprep.utils;

public class Prompts {

    public static final String NOTES_PROMPT = "You are an expert academic note maker.\n\n" +
            "From the following study material, generate:\n" +
            "1. Well-structured notes\n" +
            "2. Important key points\n" +
            "3. Definitions\n" +
            "4. Short explanations\n" +
            "5. Bullet format\n" +
            "6. Highlight important concepts\n" +
            "7. Keep it exam oriented\n" +
            "8. Add 5 short revision points at the end";

    public static final String MCQ_PROMPT = "You are an exam question generator.\n\n" +
            "From the following study material, generate 10 multiple choice questions.\n" +
            "Rules:\n" +
            "- Each question must have 4 options\n" +
            "- Only one correct answer\n" +
            "- Mix easy, medium, hard difficulty\n" +
            "- Avoid duplicate questions\n" +
            "- Output must be STRICT JSON format\n\n" +
            "Format:\n" +
            "[\n" +
            "  {\n" +
            "    \"question\": \"\",\n" +
            "    \"optionA\": \"\",\n" +
            "    \"optionB\": \"\",\n" +
            "    \"optionC\": \"\",\n" +
            "    \"optionD\": \"\",\n" +
            "    \"correctAnswer\": \"\",\n" +
            "    \"difficulty\": \"EASY\"\n" +
            "  }\n" +
            "]\n" +
            "Return ONLY the JSON array, no other text.";

    public static final String WEAK_AREA_PROMPT = "Based on these incorrect answers:\n\n" +
            "{{WRONG_QUESTIONS}}\n\n" +
            "Analyze:\n" +
            "1. Weak topics\n" +
            "2. Suggested revision strategy\n" +
            "3. Recommended focus areas\n" +
            "4. Study plan for 3 days";
}
