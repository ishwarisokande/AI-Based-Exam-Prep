package com.examprep.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DashboardStatsDto {
    private long totalMaterials;
    private long totalNotes;
    private long totalQuizzes;
    private double averageScore;
}
