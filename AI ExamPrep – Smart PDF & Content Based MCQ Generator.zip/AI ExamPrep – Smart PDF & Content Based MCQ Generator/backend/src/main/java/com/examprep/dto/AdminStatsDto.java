package com.examprep.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AdminStatsDto {
    private long totalUsers;
    private long totalMaterials;
    private long totalQuizzes;
    private long activeUsersToday;
}
