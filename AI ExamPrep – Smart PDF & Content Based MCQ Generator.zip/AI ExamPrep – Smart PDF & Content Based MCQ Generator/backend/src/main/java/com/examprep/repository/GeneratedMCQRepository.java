package com.examprep.repository;

import com.examprep.model.GeneratedMCQ;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GeneratedMCQRepository extends JpaRepository<GeneratedMCQ, Long> {
    List<GeneratedMCQ> findByMaterialId(Long materialId);
}
