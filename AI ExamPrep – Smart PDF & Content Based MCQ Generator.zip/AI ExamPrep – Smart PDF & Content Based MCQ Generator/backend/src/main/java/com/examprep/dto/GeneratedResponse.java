package com.examprep.dto;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class GeneratedResponse {
    private Long materialId;
    private String title;
    private String notes;
    private List<MCQDto> mcqs;
}
