package com.examprep.repository;

import com.examprep.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    long countByRole(com.examprep.model.Role role);

    java.util.List<User> findAllByRole(com.examprep.model.Role role);
}
