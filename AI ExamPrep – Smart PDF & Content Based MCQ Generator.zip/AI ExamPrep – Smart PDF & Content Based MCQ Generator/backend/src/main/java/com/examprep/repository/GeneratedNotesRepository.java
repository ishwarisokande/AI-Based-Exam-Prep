package com.examprep.repository;

import com.examprep.model.GeneratedNotes;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GeneratedNotesRepository extends JpaRepository<GeneratedNotes, Long> {
    Optional<GeneratedNotes> findByMaterialId(Long materialId);
}
