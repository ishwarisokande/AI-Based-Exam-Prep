package com.examprep.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.http.StreamingHttpOutputMessage.Body;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.function.ServerRequest.Headers;

import java.util.*;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String geminiApiKey;

    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=";

    private final RestTemplate restTemplate = new RestTemplate();

    public String generateContent(String prompt, String content) {
        return generateContent(prompt, content, null, null);
    }

    @SuppressWarnings("unchecked")
    public String generateContent(String prompt,
            String content,
            byte[] fileData,
            String mimeType) {

        String fullPrompt = prompt;

        if (content != null && !content.isBlank()) {
            fullPrompt += "\n\nStudy Material:\n" + content;
        }

        String url = GEMINI_API_URL + geminiApiKey;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> requestBody = new HashMap<>();

        List<Map<String, Object>> contents = new ArrayList<>();

        Map<String, Object> contentMap = new HashMap<>();
        List<Map<String, Object>> parts = new ArrayList<>();

        Map<String, Object> textPart = new HashMap<>();
        textPart.put("text", fullPrompt);

        parts.add(textPart);

        contentMap.put("parts", parts);

        contents.add(contentMap);

        requestBody.put("contents", contents);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        try {

            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    new ParameterizedTypeReference<Map<String, Object>>() {
                    });

            return extractTextFromResponse(response.getBody());

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to generate content from Gemini API: "
                            + e.getMessage(),
                    e);
        }
    }

    @SuppressWarnings("unchecked")
    private String extractTextFromResponse(
            Map<String, Object> responseBody) {

        if (responseBody == null) {
            throw new RuntimeException("Empty response from Gemini");
        }

        List<Map<String, Object>> candidates = (List<Map<String, Object>>) responseBody.get("candidates");

        if (candidates == null || candidates.isEmpty()) {
            throw new RuntimeException(
                    "No candidates found in Gemini response");
        }

        Map<String, Object> candidate = candidates.get(0);

        Map<String, Object> content = (Map<String, Object>) candidate.get("content");

        if (content == null) {
            throw new RuntimeException(
                    "No content found in Gemini response");
        }

        List<Map<String, Object>> parts = (List<Map<String, Object>>) content.get("parts");

        if (parts == null || parts.isEmpty()) {
            throw new RuntimeException(
                    "No parts found in Gemini response");
        }

        return String.valueOf(parts.get(0).get("text"));
    }
}
