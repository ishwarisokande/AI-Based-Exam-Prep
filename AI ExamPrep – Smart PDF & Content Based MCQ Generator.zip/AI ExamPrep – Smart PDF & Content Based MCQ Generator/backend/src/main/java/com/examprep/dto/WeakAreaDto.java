package com.examprep.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WeakAreaDto {
    private String topic;
    private Double averageScore;
    private Integer attempts;
    private String difficultyLevel;
    private String suggestion;
}
