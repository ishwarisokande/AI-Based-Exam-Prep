package com.examprep.model;

public enum Role {
    USER,
    ADMIN
}
