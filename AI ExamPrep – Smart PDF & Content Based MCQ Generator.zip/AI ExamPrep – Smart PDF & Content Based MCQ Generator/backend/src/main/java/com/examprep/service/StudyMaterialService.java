package com.examprep.service;

import com.examprep.dto.GeneratedResponse;
import com.examprep.dto.MCQDto;
import com.examprep.dto.StudyMaterialDto;
import com.examprep.model.GeneratedMCQ;
import com.examprep.model.GeneratedNotes;
import com.examprep.model.MaterialType;
import com.examprep.model.StudyMaterial;
import com.examprep.model.User;
import com.examprep.repository.GeneratedMCQRepository;
import com.examprep.repository.GeneratedNotesRepository;
import com.examprep.repository.StudyMaterialRepository;
import com.examprep.repository.UserRepository;
import com.examprep.utils.Prompts;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudyMaterialService {

        private final StudyMaterialRepository studyMaterialRepository;
        private final GeneratedNotesRepository notesRepository;
        private final GeneratedMCQRepository mcqRepository;
        private final UserRepository userRepository;
        private final PdfExtractionService pdfExtractionService;
        private final GeminiService geminiService;
        private final ObjectMapper objectMapper;

        @Transactional
        public GeneratedResponse processUpload(MultipartFile file, String title, String userEmail, String type,
                        String youtubeUrl, Integer questions, String difficulty) throws IOException {
                User user = userRepository.findByEmail(userEmail)
                                .orElseThrow(() -> new RuntimeException("User not found"));

                String normalizedTitle = (title == null || title.isBlank()) ? "Untitled Material" : title.trim();
                MaterialType materialType;
                try {
                        materialType = MaterialType.valueOf(type == null ? "PDF" : type.trim().toUpperCase());
                } catch (Exception e) {
                        materialType = MaterialType.PDF;
                }

                String contentType = file != null && !file.isEmpty() ? file.getContentType() : null;
                String extractedText = "";
                byte[] fileBytes = file != null && !file.isEmpty() ? file.getBytes() : null;

                switch (materialType) {
                        case YOUTUBE:
                                if (youtubeUrl == null || youtubeUrl.isBlank()) {
                                        throw new IllegalArgumentException(
                                                        "YouTube URL is required for YouTube uploads.");
                                }
                                extractedText = fetchYoutubeTranscript(youtubeUrl);
                                if (extractedText == null || extractedText.isBlank()) {
                                        extractedText = "Please summarize and generate notes and questions from the following YouTube video:\n"
                                                        + youtubeUrl;
                                } else {
                                        extractedText = "Please summarize and generate notes and questions from the following YouTube transcript:\n"
                                                        + extractedText;
                                }
                                fileBytes = null;
                                contentType = "text/plain";
                                break;
                        case IMAGE:
                                if (file == null || file.isEmpty()) {
                                        throw new IllegalArgumentException("Image file is required for image uploads.");
                                }
                                extractedText = "Please extract text and summarize the study material from the attached image.";
                                break;
                        case PDF:
                        default:
                                if (file == null || file.isEmpty()) {
                                        throw new IllegalArgumentException("PDF file is required for PDF uploads.");
                                }
                                try {
                                        extractedText = pdfExtractionService.extractTextFromPdf(file);
                                } catch (Exception e) {
                                        extractedText = ""; // Ignore extraction errors; Gemini can still read PDF bytes
                                                            // natively
                                }
                                break;
                }

                StudyMaterial material = StudyMaterial.builder()
                                .user(user)
                                .title(normalizedTitle)
                                .contentText(materialType == MaterialType.YOUTUBE ? youtubeUrl : extractedText)
                                .type(materialType)
                                .build();
                final StudyMaterial savedMaterial = studyMaterialRepository.save(material);

                String notesPrompt = Prompts.NOTES_PROMPT;
                String mcqPrompt = Prompts.MCQ_PROMPT;
                if (questions == null || questions <= 0) {
                        questions = 10;
                }
                mcqPrompt += "\n\nGenerate " + questions + " multiple choice questions.";
                if (difficulty != null && !difficulty.isBlank()) {
                        mcqPrompt += "\nPreferred difficulty: " + difficulty.toUpperCase() + ".";
                }

                String generatedNotesText = geminiService.generateContent(notesPrompt, extractedText, fileBytes,
                                contentType);
                GeneratedNotes notes = GeneratedNotes.builder()
                                .material(savedMaterial)
                                .notesText(generatedNotesText)
                                .build();
                notesRepository.save(Objects.requireNonNull(notes));

                String mcqJsonString = geminiService.generateContent(mcqPrompt, extractedText, fileBytes, contentType);
                mcqJsonString = mcqJsonString.replaceAll("```json", "").replaceAll("```", "").trim();
                mcqJsonString = extractJsonArray(mcqJsonString);

                List<MCQDto> mcqDtos;
                try {
                        mcqDtos = objectMapper.readValue(mcqJsonString, new TypeReference<List<MCQDto>>() {
                        });
                } catch (Exception e) {
                        throw new RuntimeException("Failed to parse MCQs from Gemini output: " + mcqJsonString, e);
                }

                List<GeneratedMCQ> mcqs = mcqDtos.stream().map(dto -> GeneratedMCQ.builder()
                                .material(savedMaterial)
                                .question(dto.getQuestion())
                                .optionA(dto.getOptionA())
                                .optionB(dto.getOptionB())
                                .optionC(dto.getOptionC())
                                .optionD(dto.getOptionD())
                                .correctAnswer(dto.getCorrectAnswer())
                                .difficulty(dto.getDifficulty() != null ? dto.getDifficulty() : "MEDIUM")
                                .build()).collect(Collectors.toList());

                mcqRepository.saveAll(Objects.requireNonNull(mcqs));

                return GeneratedResponse.builder()
                                .materialId(savedMaterial.getId())
                                .title(savedMaterial.getTitle())
                                .notes(generatedNotesText)
                                .mcqs(mcqs.stream().map(m -> MCQDto.builder()
                                                .id(m.getId())
                                                .question(m.getQuestion())
                                                .optionA(m.getOptionA())
                                                .optionB(m.getOptionB())
                                                .optionC(m.getOptionC())
                                                .optionD(m.getOptionD())
                                                .correctAnswer(m.getCorrectAnswer())
                                                .difficulty(m.getDifficulty())
                                                .build()).collect(Collectors.toList()))
                                .build();
        }

        private String extractJsonArray(String text) {
                if (text == null) {
                        return null;
                }
                int start = text.indexOf('[');
                int end = text.lastIndexOf(']');
                if (start >= 0 && end > start) {
                        return text.substring(start, end + 1);
                }
                return text;
        }

        public List<StudyMaterialDto> getUserMaterials(String userEmail) {
                User user = userRepository.findByEmail(userEmail)
                                .orElseThrow(() -> new RuntimeException("User not found"));

                return studyMaterialRepository.findByUserId(user.getId()).stream()
                                .map(m -> StudyMaterialDto.builder()
                                                .id(m.getId())
                                                .title(m.getTitle())
                                                .type(m.getType())
                                                .uploadedAt(m.getUploadedAt())
                                                .build())
                                .collect(Collectors.toList());
        }

        public GeneratedResponse getMaterialContent(Long materialId, String userEmail) {
                if (materialId == null) {
                        throw new IllegalArgumentException("Material ID cannot be null");
                }
                StudyMaterial material = studyMaterialRepository.findById(materialId)
                                .orElseThrow(() -> new RuntimeException("Material not found"));

                if (!material.getUser().getEmail().equals(userEmail)) {
                        throw new RuntimeException("Unauthorized access to material");
                }

                GeneratedNotes notes = notesRepository.findByMaterialId(materialId)
                                .orElseThrow(() -> new RuntimeException("Notes not found"));

                List<GeneratedMCQ> mcqs = mcqRepository.findByMaterialId(materialId);

                return GeneratedResponse.builder()
                                .materialId(materialId)
                                .title(material.getTitle())
                                .notes(notes.getNotesText())
                                .mcqs(mcqs.stream().map(m -> MCQDto.builder()
                                                .id(m.getId())
                                                .question(m.getQuestion())
                                                .optionA(m.getOptionA())
                                                .optionB(m.getOptionB())
                                                .optionC(m.getOptionC())
                                                .optionD(m.getOptionD())
                                                .correctAnswer(m.getCorrectAnswer())
                                                .difficulty(m.getDifficulty())
                                                .build()).collect(Collectors.toList()))
                                .build();
        }

        private String fetchYoutubeTranscript(String youtubeUrl) {
                try {
                        String videoId = extractYoutubeVideoId(youtubeUrl);
                        if (videoId == null) {
                                return null;
                        }

                        String transcriptUrl = "https://youtubetranscript.com/?server_vid="
                                        + URLEncoder.encode(videoId, StandardCharsets.UTF_8);
                        RestTemplate restTemplate = new RestTemplate();
                        String html = restTemplate.getForObject(transcriptUrl, String.class);
                        if (html == null) {
                                return null;
                        }

                        Pattern pattern = Pattern.compile("<div class=\"text\".*?>(.*?)</div>", Pattern.DOTALL);
                        Matcher matcher = pattern.matcher(html);
                        StringBuilder transcript = new StringBuilder();
                        while (matcher.find()) {
                                String text = matcher.group(1).replaceAll("<.*?>", "").trim();
                                if (!text.isEmpty()) {
                                        transcript.append(text).append(" ");
                                }
                        }

                        String result = transcript.toString().trim();
                        return result.isEmpty() ? null : result;
                } catch (Exception e) {
                        return null;
                }
        }

        private String extractYoutubeVideoId(String youtubeUrl) {
                if (youtubeUrl == null) {
                        return null;
                }
                String url = youtubeUrl.trim();

                Pattern pattern = Pattern.compile("(?:v=|youtu\\.be/|embed/)([A-Za-z0-9_-]{11})");
                Matcher matcher = pattern.matcher(url);
                if (matcher.find()) {
                        return matcher.group(1);
                }
                return null;
        }
}
