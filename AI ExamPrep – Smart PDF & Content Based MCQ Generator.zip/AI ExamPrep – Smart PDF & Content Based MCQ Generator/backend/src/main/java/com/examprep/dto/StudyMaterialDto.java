package com.examprep.dto;

import com.examprep.model.MaterialType;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class StudyMaterialDto {
    private Long id;
    private String title;
    private MaterialType type;
    private LocalDateTime uploadedAt;
}
