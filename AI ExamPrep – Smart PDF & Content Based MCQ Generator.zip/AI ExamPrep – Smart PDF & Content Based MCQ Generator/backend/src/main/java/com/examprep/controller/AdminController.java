package com.examprep.controller;

import com.examprep.dto.AdminStatsDto;
import com.examprep.model.GeneratedMCQ;
import com.examprep.model.Role;
import com.examprep.model.User;
import com.examprep.repository.GeneratedMCQRepository;
import com.examprep.repository.QuizResultRepository;
import com.examprep.repository.StudyMaterialRepository;
import com.examprep.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final StudyMaterialRepository materialRepository;
    private final QuizResultRepository quizRepository;
    private final GeneratedMCQRepository mcqRepository;

    @GetMapping("/stats")
    public ResponseEntity<AdminStatsDto> getStats() {
        return ResponseEntity.ok(AdminStatsDto.builder()
                .totalUsers(userRepository.count())
                .totalMaterials(materialRepository.count())
                .totalQuizzes(quizRepository.count())
                .activeUsersToday(userRepository.countByRole(Role.USER)) // Placeholder logic
                .build());
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        if (id == null)
            return ResponseEntity.badRequest().build();
        userRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/content")
    public ResponseEntity<List<?>> getAllContent() {
        return ResponseEntity.ok(materialRepository.findAll());
    }

    @DeleteMapping("/content/{id}")
    public ResponseEntity<Void> deleteContent(@PathVariable Long id) {
        if (id == null)
            return ResponseEntity.badRequest().build();
        materialRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/mcqs")
    public ResponseEntity<List<GeneratedMCQ>> getAllMCQs() {
        return ResponseEntity.ok(mcqRepository.findAll());
    }

    @DeleteMapping("/mcqs/{id}")
    public ResponseEntity<Void> deleteMCQ(@PathVariable Long id) {
        if (id == null)
            return ResponseEntity.badRequest().build();
        mcqRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/analytics/detailed")
    public ResponseEntity<?> getDetailedAnalytics() {
        // Return a simplified map for system-wide stats
        return ResponseEntity.ok(java.util.Map.of(
                "totalUsers", userRepository.count(),
                "totalUploads", materialRepository.count(),
                "totalQuizzes", quizRepository.count(),
                "totalMCQs", mcqRepository.count()));
    }

    @GetMapping("/logs")
    public ResponseEntity<List<?>> getSystemLogs() {
        // Mock logs for now since we don't have a dedicated ActivityLog entity
        return ResponseEntity.ok(List.of(
                java.util.Map.of("event", "New User Registered", "time", "10 mins ago"),
                java.util.Map.of("event", "Gemini Generated 5 MCQs", "time", "25 mins ago"),
                java.util.Map.of("event", "Admin accessed secure panel", "time", "1 hour ago")));
    }
}
