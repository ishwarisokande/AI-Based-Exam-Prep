package com.examprep.controller;

import com.examprep.dto.DashboardStatsDto;
import com.examprep.repository.QuizResultRepository;
import com.examprep.repository.StudyMaterialRepository;
import com.examprep.repository.UserRepository;
import com.examprep.service.AnalyticsService;
import com.examprep.model.User;
import com.examprep.model.QuizResult;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dashboard")
@RequiredArgsConstructor
public class DashboardController {

        private final StudyMaterialRepository materialRepository;
        private final QuizResultRepository quizRepository;
        private final UserRepository userRepository;
        private final AnalyticsService analyticsService;

        @GetMapping("/stats")
        public ResponseEntity<DashboardStatsDto> getStats() {
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                User user = userRepository.findByEmail(authentication.getName())
                                .orElseThrow(() -> new RuntimeException("User not found"));

                long totalMaterials = materialRepository.findByUserId(user.getId()).size();

                // Notes count is 1:1 with Material in this implementation
                long totalNotes = totalMaterials;

                List<QuizResult> quizzes = quizRepository.findByUserIdOrderByDateDesc(user.getId());
                long totalQuizzes = quizzes.size();

                double avgScore = quizzes.stream()
                                .mapToDouble(q -> (double) q.getScore() / q.getTotal() * 100)
                                .average()
                                .orElse(0.0);

                return ResponseEntity.ok(DashboardStatsDto.builder()
                                .totalMaterials(totalMaterials)
                                .totalNotes(totalNotes)
                                .totalQuizzes(totalQuizzes)
                                .averageScore(avgScore)
                                .build());
        }

        @GetMapping("/analytics")
        public ResponseEntity<com.examprep.dto.PerformanceAnalyticsDto> getAdvancedAnalytics() {
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                User user = userRepository.findByEmail(authentication.getName())
                                .orElseThrow(() -> new RuntimeException("User not found"));
                return ResponseEntity.ok(analyticsService.getUserAnalytics(user));
        }
}
