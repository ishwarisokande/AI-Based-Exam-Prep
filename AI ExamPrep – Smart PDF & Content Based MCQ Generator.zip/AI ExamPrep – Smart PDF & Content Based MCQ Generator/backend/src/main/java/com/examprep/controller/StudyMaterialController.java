package com.examprep.controller;

import com.examprep.dto.GeneratedResponse;
import com.examprep.dto.StudyMaterialDto;
import com.examprep.service.StudyMaterialService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/materials")
@RequiredArgsConstructor
public class StudyMaterialController {

    private final StudyMaterialService studyMaterialService;

    @PostMapping("/upload")
    public ResponseEntity<GeneratedResponse> uploadMaterial(
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "title", required = false) String title,
            @RequestParam(value = "type", defaultValue = "pdf") String type,
            @RequestParam(value = "youtubeUrl", required = false) String youtubeUrl,
            @RequestParam(value = "questions", required = false) Integer questions,
            @RequestParam(value = "difficulty", required = false) String difficulty) throws IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        return ResponseEntity.ok(studyMaterialService.processUpload(file, title, currentPrincipalName, type, youtubeUrl,
                questions, difficulty));
    }

    @GetMapping
    public ResponseEntity<List<StudyMaterialDto>> getUserMaterials() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        return ResponseEntity.ok(studyMaterialService.getUserMaterials(currentPrincipalName));
    }

    @GetMapping("/{id}/content")
    public ResponseEntity<GeneratedResponse> getMaterialContent(@PathVariable("id") Long materialId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        return ResponseEntity.ok(studyMaterialService.getMaterialContent(materialId, currentPrincipalName));
    }
}
