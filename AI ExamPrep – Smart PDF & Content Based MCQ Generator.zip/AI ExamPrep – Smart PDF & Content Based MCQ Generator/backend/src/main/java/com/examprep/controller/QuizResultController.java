package com.examprep.controller;

import com.examprep.dto.QuizResultDto;
import com.examprep.model.QuizResult;
import com.examprep.model.User;
import com.examprep.repository.QuizResultRepository;
import com.examprep.repository.StudyMaterialRepository;
import com.examprep.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/quiz")
@RequiredArgsConstructor
public class QuizResultController {

        private final QuizResultRepository quizResultRepository;
        private final UserRepository userRepository;
        private final StudyMaterialRepository materialRepository;

        @PostMapping("/save")
        public ResponseEntity<QuizResultDto> saveResult(@RequestBody QuizResultDto request) {
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                User user = userRepository.findByEmail(authentication.getName())
                                .orElseThrow(() -> new RuntimeException("User not found"));

                QuizResult.QuizResultBuilder builder = QuizResult.builder()
                                .user(user)
                                .score(request.getScore())
                                .total(request.getTotal());

                if (request.getMaterialId() != null) {
                        Long materialId = request.getMaterialId();
                        if (materialId != null) {
                                materialRepository.findById(materialId).ifPresent(builder::material);
                        }
                }

                QuizResult quizResult = builder.build();

                @SuppressWarnings("null")
                QuizResult saved = quizResultRepository.save(quizResult);

                return ResponseEntity.ok(QuizResultDto.builder()
                                .id(saved.getId())
                                .materialId(saved.getMaterial() != null ? saved.getMaterial().getId() : null)
                                .score(saved.getScore())
                                .total(saved.getTotal())
                                .date(saved.getDate())
                                .build());
        }

        @GetMapping("/history")
        public ResponseEntity<List<QuizResultDto>> getHistory() {
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                User user = userRepository.findByEmail(authentication.getName())
                                .orElseThrow(() -> new RuntimeException("User not found"));

                List<QuizResultDto> history = quizResultRepository.findByUserIdOrderByDateDesc(user.getId())
                                .stream()
                                .map(q -> QuizResultDto.builder()
                                                .id(q.getId())
                                                .materialId(q.getMaterial() != null ? q.getMaterial().getId() : null)
                                                .score(q.getScore())
                                                .total(q.getTotal())
                                                .date(q.getDate())
                                                .build())
                                .collect(Collectors.toList());

                return ResponseEntity.ok(history);
        }
}
