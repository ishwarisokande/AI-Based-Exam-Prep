package com.examprep.service;

import com.examprep.dto.PerformanceAnalyticsDto;
import com.examprep.dto.WeakAreaDto;
import com.examprep.model.QuizResult;
import com.examprep.model.StudyMaterial;
import com.examprep.model.User;
import com.examprep.repository.QuizResultRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final QuizResultRepository quizRepository;
    private final GeminiService geminiService;

    public PerformanceAnalyticsDto getUserAnalytics(User user) {
        List<QuizResult> quizzes = quizRepository.findByUserIdOrderByDateDesc(user.getId());

        if (quizzes.isEmpty()) {
            return PerformanceAnalyticsDto.builder()
                    .overallProgress(0.0)
                    .geminiSummary("Start taking quizzes to see your analysis!")
                    .build();
        }

        // Group by material (topic)
        Map<StudyMaterial, List<QuizResult>> byTopic = quizzes.stream()
                .filter(q -> q.getMaterial() != null)
                .collect(Collectors.groupingBy(QuizResult::getMaterial));

        List<WeakAreaDto> weakAreas = new ArrayList<>();
        for (Map.Entry<StudyMaterial, List<QuizResult>> entry : byTopic.entrySet()) {
            List<QuizResult> topicQuizzes = entry.getValue();
            double avg = topicQuizzes.stream().mapToDouble(q -> (double) q.getScore() / q.getTotal() * 100).average()
                    .orElse(0.0);

            if (avg < 70.0) {
                weakAreas.add(WeakAreaDto.builder()
                        .topic(entry.getKey().getTitle())
                        .averageScore(avg)
                        .attempts(topicQuizzes.size())
                        .suggestion("Focus on " + entry.getKey().getTitle() + " basics.")
                        .build());
            }
        }

        // Generate Gemini Summary
        String prompt = "Based on the following quiz performance data (Topic: Average Score), provide a short summary of weak areas and 3 specific study recommendations. Keep it concise.";
        String statsContent = byTopic.entrySet().stream()
                .map(e -> e.getKey().getTitle() + ": "
                        + Math.round(e.getValue().stream().mapToDouble(q -> (double) q.getScore() / q.getTotal() * 100)
                                .average().orElse(0.0))
                        + "%")
                .collect(Collectors.joining("\n"));

        String geminiInsight = geminiService.generateContent(prompt, statsContent);

        return PerformanceAnalyticsDto.builder()
                .weakAreas(weakAreas)
                .geminiSummary(geminiInsight)
                .overallProgress(quizzes.stream().mapToDouble(q -> (double) q.getScore() / q.getTotal() * 100).average()
                        .orElse(0.0))
                .build();
    }
}
