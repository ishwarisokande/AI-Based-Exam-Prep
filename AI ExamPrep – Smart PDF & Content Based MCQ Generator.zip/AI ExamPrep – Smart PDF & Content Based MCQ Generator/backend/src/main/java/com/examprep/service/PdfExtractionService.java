package com.examprep.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class PdfExtractionService {

    public String extractTextFromPdf(MultipartFile file) throws IOException {
        try (PDDocument document = Loader.loadPDF(file.getInputStream().readAllBytes())) {
            PDFTextStripper pdfStripper = new PDFTextStripper();

            // Limit to first 10 pages maximum for performance & token limits
            pdfStripper.setStartPage(1);
            pdfStripper.setEndPage(Math.min(10, document.getNumberOfPages()));

            String text = pdfStripper.getText(document);
            if (text == null || text.trim().isEmpty()) {
                throw new IllegalArgumentException("No readable text found. Please ensure your PDF is not just scanned images.");
            }
            return text;
        }
    }
}
