package com.examprep.model;

public enum MaterialType {
    PDF,
    YOUTUBE,
    IMAGE,
    TEXT
}
