package com.examprep.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class QuizResultDto {
    private Long id;
    private Long materialId;
    private Integer score;
    private Integer total;
    private LocalDateTime date;
}
