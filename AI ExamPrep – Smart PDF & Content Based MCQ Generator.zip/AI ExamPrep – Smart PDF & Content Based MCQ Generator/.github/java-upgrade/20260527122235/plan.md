# Upgrade Plan: AI ExamPrep (20260527122235)

- **Generated**: 2026-05-27 12:22
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 21.0.6: C:\Program Files\Java\jdk-21\bin (target, used by all upgrade steps)

**Build Tools**
- Maven 3.9.12: C:\Program Files\apache-maven-3.9.12-bin\apache-maven-3.9.12\bin

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260527122235
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime to latest LTS (Java 21)

## Technology Stack

| Technology/Dependency    | Current | Min Compatible | Why Incompatible                               |
| ------------------------ | ------- | -------------- | ---------------------------------------------- |
| Java                     | 17      | 21             | User requested                                 |
| Spring Boot              | 3.2.4   | 3.2.4          | Compatible                                    |
| Maven                    | 3.9.12  | 3.9.0          | Compatible                                    |
| maven-compiler-plugin    | (none)  | 3.11.0         | Required for Java 21 compatibility             |
| maven-surefire-plugin    | (none)  | 3.1.0          | Recommended for Java 17+                       |
| jjwt                     | 0.11.5  | 0.11.5         | Compatible                                    |
| pdfbox                   | 3.0.2   | 3.0.2          | Compatible                                    |
| mysql-connector-j        | (Maven managed) | (Maven managed) | Compatible                         |
| lombok                   | (Maven managed) | (Maven managed) | Compatible                         |

## Derived Upgrades

- Add/upgrade maven-compiler-plugin to 3.11.0+ for Java 21 compatibility
- Add/upgrade maven-surefire-plugin to 3.1.0+ for Java 17+ test compatibility

## Impact Analysis

### Dependency Changes

| File     | Dependency              | Current | Action  | Target   | Reason                                  |
|----------|-------------------------|---------|---------|----------|-----------------------------------------|
| pom.xml  | java.version            | 17      | upgrade | 21       | User requested                         |
| pom.xml  | maven-compiler-plugin   | (none)  | add     | 3.11.0   | Required for Java 21                   |
| pom.xml  | maven-surefire-plugin   | (none)  | add     | 3.1.0    | Recommended for Java 17+               |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| (none) | | | | No source code changes required for Java 21 with Spring Boot 3.2.4 |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| (none) | | | | No config changes required |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| (none) | | | |

### Risks & Warnings

- **Build plugin compatibility**: Older maven-compiler-plugin or missing plugin will cause build failure on Java 21. **Mitigation**: Add/upgrade to 3.11.0+.
- **Test plugin compatibility**: Older maven-surefire-plugin may cause test failures on Java 17+. **Mitigation**: Add/upgrade to 3.1.0+.
- **No baseline JDK 17**: Baseline test run will be skipped as JDK 17 is not available.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Ensure required JDK and Maven versions are available
  - **Changes to Make**: Use JDK 21.0.6 and Maven 3.9.12
  - **Verification**: Confirm JDK and Maven are available

- Step 2: Setup Baseline
  - **Rationale**: Establish baseline test results (skipped, JDK 17 not available)
  - **Changes to Make**: None
  - **Verification**: Skipped

- Step 3: Upgrade Java version and build plugins
  - **Rationale**: Update project to use Java 21 and ensure build plugins are compatible
  - **Changes to Make**: Apply all Dependency Changes for Java 21 compatibility
  - **Verification**: mvn clean test-compile -q (JDK 21)

- Step 4: Final Validation
  - **Rationale**: Ensure all goals are met and tests pass
  - **Changes to Make**: Full clean build and test
  - **Verification**: mvn clean test -q (JDK 21), expect 100% test pass
